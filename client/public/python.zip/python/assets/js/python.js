$("p").hover(function(){
    $(this).css("background-color", "black");
    }, function(){
    $(this).css("background-color", "pink");
});

$(".admin").mouseenter(hi=>{
    $('.show').append('Enter admin Admin')
    $('.show').show();
})
$(".admin").mouseleave(hi=>{
    $('.show').hide();
        $('.show').hide();
        $('.show').html('')
   
})